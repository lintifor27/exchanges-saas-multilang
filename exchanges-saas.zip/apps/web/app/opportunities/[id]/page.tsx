import { notFound } from 'next/navigation';

async function getOpportunity(id: string) {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';
  const res = await fetch(`${apiUrl}/opportunities/${id}`);
  if (!res.ok) return null;
  return res.json();
}

export default async function OpportunityPage({ params }: { params: { id: string } }) {
  const opp = await getOpportunity(params.id);
  if (!opp) notFound();
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Opportunity Detail</h2>
      <pre className="bg-gray-100 p-4 rounded text-sm overflow-x-auto">
        {JSON.stringify(opp, null, 2)}
      </pre>
    </div>
  );
}