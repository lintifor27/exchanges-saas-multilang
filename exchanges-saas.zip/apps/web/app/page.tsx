import Link from 'next/link';

async function getExchanges() {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';
  const res = await fetch(`${apiUrl}/exchanges`);
  if (!res.ok) return [];
  return res.json();
}

export default async function HomePage() {
  const exchanges: any[] = await getExchanges();
  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Exchanges</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {exchanges.map((ex) => (
          <div key={ex.id} className="bg-white rounded shadow p-4">
            <h3 className="text-lg font-bold">{ex.name}</h3>
            <p className="text-sm text-gray-500">{ex.ccxtId}</p>
            <div className="mt-2 flex space-x-2">
              <Link className="text-blue-600 underline" href={`/exchanges/${ex.slug}`}>Details</Link>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-2">Scanners</h2>
        <ul className="list-disc pl-6 space-y-1">
          <li>
            <Link href="/scanners/cex" className="text-blue-600 underline">Spot Arbitrage (CEX↔CEX)</Link>
          </li>
          <li>
            <Link href="/scanners/tri" className="text-blue-600 underline">Triangular Arbitrage</Link>
          </li>
          <li>
            <Link href="/scanners/p2p" className="text-blue-600 underline">P2P Scanner</Link>
          </li>
        </ul>
      </div>
    </div>
  );
}