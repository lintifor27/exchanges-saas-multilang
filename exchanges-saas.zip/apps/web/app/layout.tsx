import './globals.css';
import { ReactNode } from 'react';

export const metadata = {
  title: 'Exchanges Review & Arbitrage',
  description: 'Market analytics and arbitrage opportunities',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header className="bg-white shadow">
          <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8">
            <h1 className="text-2xl font-bold">Exchanges Analytics</h1>
          </div>
        </header>
        <main className="p-4 max-w-7xl mx-auto">{children}</main>
      </body>
    </html>
  );
}