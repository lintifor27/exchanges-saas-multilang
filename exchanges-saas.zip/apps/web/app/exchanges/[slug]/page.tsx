import { notFound } from 'next/navigation';
import Link from 'next/link';

async function getExchange(slug: string) {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';
  const res = await fetch(`${apiUrl}/exchanges/${slug}`);
  if (!res.ok) return null;
  return res.json();
}

export default async function ExchangePage({ params }: { params: { slug: string } }) {
  const exchange = await getExchange(params.slug);
  if (!exchange) notFound();
  return (
    <div>
      <h2 className="text-2xl font-bold">{exchange.name}</h2>
      <p className="text-sm text-gray-500">{exchange.ccxtId}</p>
      <p className="mt-2">Maker fee: {exchange.makerFee}</p>
      <p>Taker fee: {exchange.takerFee}</p>
      <p>P2P supported: {exchange.p2pSupported ? 'Yes' : 'No'}</p>
      <div className="mt-4">
        <Link href="/" className="text-blue-600 underline">← Back</Link>
      </div>
    </div>
  );
}